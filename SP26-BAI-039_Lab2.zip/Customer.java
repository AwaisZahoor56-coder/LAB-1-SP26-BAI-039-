/*
 * CSC241 - Object-Oriented Programming | BS Artificial Intelligence (BAI)
 * Lab Assignment 2 - Cafeteria Order Management System
 * Student: Muhammad Awais Zahoor | Reg. No: SP26-BAI-039
 * Instructor: Mr. Shahid Bhatti
 */
public class Customer {
    private int customerId;
    private String name;

    public Customer(int customerId, String name) {
        this.customerId = customerId;
        this.name = name;
    }

    public void displayCustomer() {
        System.out.println("Customer ID: " + customerId);
        System.out.println("Customer Name: " + name);
    }
}
