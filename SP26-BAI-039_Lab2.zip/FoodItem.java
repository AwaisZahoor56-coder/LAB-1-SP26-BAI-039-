/*
 * CSC241 - Object-Oriented Programming | BS Artificial Intelligence (BAI)
 * Lab Assignment 2 - Cafeteria Order Management System
 * Student: Muhammad Awais Zahoor | Reg. No: SP26-BAI-039
 * Instructor: Mr. Shahid Bhatti
 */
public class FoodItem {
    private int itemCode;
    private String name;
    private double price;
    private FoodCategory category;

    // Shorter constructor: chains to the longer one using a default category
    public FoodItem(int itemCode, String name, double price) {
        this(itemCode, name, price, FoodCategory.SNACK);
    }

    public FoodItem(int itemCode, String name, double price, FoodCategory category) {
        this.itemCode = itemCode;
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public int getItemCode() {
        return itemCode;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public FoodCategory getCategory() {
        return category;
    }

    public void displayItem() {
        System.out.println("Code: " + itemCode + " | Name: " + name
                + " | Price: Rs. " + (long) price + " | Category: " + category);
    }
}
