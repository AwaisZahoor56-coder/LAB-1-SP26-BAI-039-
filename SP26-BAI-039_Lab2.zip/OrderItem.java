/*
 * CSC241 - Object-Oriented Programming | BS Artificial Intelligence (BAI)
 * Lab Assignment 2 - Cafeteria Order Management System
 * Student: Muhammad Awais Zahoor | Reg. No: SP26-BAI-039
 * Instructor: Mr. Shahid Bhatti
 */
public class OrderItem {
    private FoodItem item;   // reference to an already-created FoodItem
    private int quantity;

    public OrderItem(FoodItem item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    public FoodItem getItem() {
        return item;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getSubTotal() {
        return item.getPrice() * quantity;
    }

    public void displayOrderItem() {
        System.out.printf("%-18s%-6d%-8.0f%.0f%n",
                item.getName(), quantity, item.getPrice(), getSubTotal());
    }
}
