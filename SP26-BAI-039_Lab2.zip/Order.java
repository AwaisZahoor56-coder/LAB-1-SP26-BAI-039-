/*
 * CSC241 - Object-Oriented Programming | BS Artificial Intelligence (BAI)
 * Lab Assignment 2 - Cafeteria Order Management System
 * Student: Muhammad Awais Zahoor | Reg. No: SP26-BAI-039
 * Instructor: Mr. Shahid Bhatti
 */
public class Order {
    private int orderNo;
    private Customer customer;     // aggregation: customer exists independently
    private OrderItem[] items;     // composition: Order creates its OrderItem objects
    private int itemCount;

    // Default capacity is 5, using this(...) chaining
    public Order(int orderNo, Customer customer) {
        this(orderNo, customer, 5);
    }

    public Order(int orderNo, Customer customer, int capacity) {
        this.orderNo = orderNo;
        this.customer = customer;
        if (capacity <= 0) {
            capacity = 5;
        }
        this.items = new OrderItem[capacity];
        this.itemCount = 0;
    }

    public void addItem(FoodItem food, int quantity) {
        if (quantity <= 0) {
            System.out.println("Cannot add item: quantity must be greater than zero.");
            return;
        }
        if (itemCount >= items.length) {
            System.out.println("Cannot add item: order is full (capacity "
                    + items.length + ").");
            return;
        }
        items[itemCount] = new OrderItem(food, quantity);
        itemCount++;
    }

    public void findItem(int itemCode) {
        for (int i = 0; i < itemCount; i++) {
            if (items[i].getItem().getItemCode() == itemCode) {
                System.out.println("Item Found: " + items[i].getItem().getName()
                        + " | Quantity: " + items[i].getQuantity());
                return;
            }
        }
        System.out.println("Item not found");
    }

    public double calculateTotal() {
        double total = 0;
        for (int i = 0; i < itemCount; i++) {
            total += items[i].getSubTotal();
        }
        return total;
    }

    public void displayOrder() {
        System.out.println("============================================");
        System.out.println(" CAFETERIA ORDER");
        System.out.println("============================================");
        System.out.println("Order No: " + orderNo);
        customer.displayCustomer();
        System.out.println("--------------------------------------------");
        System.out.printf("%-18s%-6s%-8s%s%n", "Item", "Qty", "Price", "Subtotal");
        for (int i = 0; i < itemCount; i++) {
            items[i].displayOrderItem();
        }
        System.out.println("--------------------------------------------");
        System.out.printf("Total Bill: Rs. %.0f%n", calculateTotal());
    }
}
