/*
 * CSC241 - Object-Oriented Programming | BS Artificial Intelligence (BAI)
 * Lab Assignment 2 - Cafeteria Order Management System
 * Student: Muhammad Awais Zahoor | Reg. No: SP26-BAI-039
 * Instructor: Mr. Shahid Bhatti
 */
public enum FoodCategory {
    MAIN_COURSE,
    DRINK,
    SNACK,
    DESSERT
}
