public class Main {
    public static void main(String[] args) {
        Bus bus = new Bus("GAP-704", 4);

        System.out.println("Bus Number: GAP-704");

        System.out.println("Initial Seating Arrangement:");
       
        bus.displaySeats();
       
         System.out.println("Available Seats: " + bus.countAvailableSeats());
         System.out.println("\n");



        bus.reserveSeat(3);
        bus.reserveSeat(7);
        bus.reserveSeat(12);
        bus.reserveSeat(7);

        System.out.println("\n");


        System.out.println("Updated Seating Arrangement:");
        
        bus.displaySeats();

        System.out.println("\n");

         System.out.println("Available Seats: " + bus.countAvailableSeats());

        Bus defaultBus = new Bus();
        
         System.out.println("Default Bus:");
        
         defaultBus.displaySeats();
        
        System.out.println("\n");


          System.out.println("Available Seats: " + defaultBus.countAvailableSeats());
    }
}